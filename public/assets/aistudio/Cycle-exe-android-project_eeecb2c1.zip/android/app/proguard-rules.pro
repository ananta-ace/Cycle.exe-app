-keepattributes *Annotation*
-keepclassmembers class com.cycleexe.app.MainActivity$CycleAndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
